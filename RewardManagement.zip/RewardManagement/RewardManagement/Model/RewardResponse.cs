﻿namespace RewardManagement.Model
{
    public class RewardResponse
    {
        public bool IsSuccess { get; set; }
        public int RewardPoint { get; set; }
    }
}
