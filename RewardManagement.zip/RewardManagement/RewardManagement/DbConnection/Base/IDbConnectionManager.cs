﻿using System.Data.SqlClient;

namespace RewardManagement.DbConnection.Base
{
    public interface IDbConnectionManager
    {
        SqlConnection GetConnection();
    }
}
