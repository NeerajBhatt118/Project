﻿using RewardManagement.DbConnection.Base;
using System.Data.SqlClient;

namespace RewardManagement.DbConnection
{
    public class DbConnectionManager : IDbConnectionManager
    {
        private readonly IConfiguration configuration;

        public DbConnectionManager(IConfiguration config)
        {
            configuration = config;
        }

        public SqlConnection GetConnection()
        {
           return new SqlConnection(configuration.GetConnectionString("Connection"));
        }
    }
}
