using Microsoft.AspNetCore;

namespace RewardManagement
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }
        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
       WebHost.CreateDefaultBuilder(args)
            .UseIIS()
            .UseContentRoot(Directory.GetCurrentDirectory())
            .UseStartup<Startup>();
            // .UseUrls("https://*:5001")            
    }
}