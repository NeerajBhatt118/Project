using Microsoft.AspNetCore.Mvc;
using RewardManagement.Model;
using RewardManagement.Service.Base;

namespace RewardManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RewardManagerController : ControllerBase
    {
        IRewardService iRewardService;
        public RewardManagerController(IRewardService rewardService)
        {
            iRewardService = rewardService;
        }
        public RewardResponse RewardCalucation(float amount)
        {
            return iRewardService.CalculateReward(amount);
        }
    }
}