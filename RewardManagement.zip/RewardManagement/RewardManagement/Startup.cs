﻿using RewardManagement.DbConnection;
using RewardManagement.DbConnection.Base;
using RewardManagement.Service;
using RewardManagement.Service.Base;

namespace RewardManagement
{
    public class Startup
    {
        public IConfiguration iConfiguration { get; }
        public Startup(IConfiguration configuration)
        {
            iConfiguration = configuration;
        }
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IDbConnectionManager, DbConnectionManager>();
            services.AddTransient<IRewardService, RewardService>();

            services.AddMvc();
        }
        public void Configure(IApplicationBuilder app, IServiceProvider services)
        {
            app.UseRouting();
        }
    }
}
