﻿using RewardManagement.Model;

namespace RewardManagement.Service.Base
{
    public interface IRewardService
    {
        public RewardResponse CalculateReward(float amount);
    }
}
