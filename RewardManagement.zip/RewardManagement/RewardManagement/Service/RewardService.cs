﻿using RewardManagement.Model;
using RewardManagement.Service.Base;

namespace RewardManagement.Service
{
    public class RewardService : IRewardService
    {
        public RewardResponse CalculateReward(float amount)
        {
            RewardResponse rewardResponse = new RewardResponse();
            switch (amount)
            {
                case > 50 and < 100:
                    rewardResponse.RewardPoint = (int)((amount - 50) * 1);
                    rewardResponse.IsSuccess = true;
                    break;
                case > 100:
                    rewardResponse.RewardPoint = (int)((amount - 50) * 1) + (int)((amount - 100) * 1);
                    rewardResponse.IsSuccess = true;
                    break;
                case > 0 and < 50:
                    rewardResponse.RewardPoint = 0;
                    rewardResponse.IsSuccess = true;
                    break;
                default:
                    rewardResponse.RewardPoint = 0;
                    rewardResponse.IsSuccess = false;
                    break;
            }
            return rewardResponse;
        }
    }
}
